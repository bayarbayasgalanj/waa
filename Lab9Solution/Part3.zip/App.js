import './App.css';
import React from 'react';
import CountersContainer from './CountersContainer';

function App() {
  return (
      <CountersContainer />
  );
}

export default App;