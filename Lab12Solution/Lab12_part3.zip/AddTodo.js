import React, { useState } from 'react';
import { connect } from 'react-redux';
import { addTodo } from './redux/actions';

const TodoInput = ({ addTodo }) => {
    const [todoText, setTodoText] = useState('');

    const handleInputChange = (e) => {
        setTodoText(e.target.value);
    };

    const handleAddTodo = () => {
        if (todoText.trim() !== '') {
            addTodo(todoText);
            setTodoText('');
        }
    };

    return (
        <div>
            <h2>Add New Todo</h2>
            <input type="text" placeholder="Enter todo..." value={todoText} onChange={handleInputChange} />
            <button onClick={handleAddTodo}>Add</button>
        </div>
    );
};

const mapDispatchToProps = {
    addTodo,
};

export default connect(null, mapDispatchToProps)(TodoInput);
