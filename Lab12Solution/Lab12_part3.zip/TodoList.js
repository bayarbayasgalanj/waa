import React from 'react';
import { connect } from 'react-redux';
import { removeTodo } from './redux/actions';

const TodoList = ({ todos, removeTodo }) => {
    return (
        <div>
            <h2>Todo List</h2>
            <ul>
                {todos.map((todo, index) => (
                    <li key={index}>
                        {todo}
                        <button onClick={() => removeTodo(index)}>Remove</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        todos: state.todos,
    };
};

const mapDispatchToProps = {
    removeTodo,
};

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
