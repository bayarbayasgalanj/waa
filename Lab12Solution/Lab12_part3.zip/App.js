import React from 'react';
import { connect } from 'react-redux';
import TodoList from './TodoList';
import AddTodo from './AddTodo';

const TodoApp = () => {
  return (
    <div className="app">
      <h1>Todo List</h1>
      <TodoList />
      <AddTodo />
    </div>
  );
};

export default TodoApp;
