import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Bank from './Bank';
import React, { useState } from 'react';

function App() {
  return (
    <div>
      <Bank/>
    </div>
  );
}

export default App;