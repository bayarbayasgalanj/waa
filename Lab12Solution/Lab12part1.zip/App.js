import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Book from './Book';
import React, { useState } from 'react';

function App() {
  return (
    <div>
      <Book/>
    </div>
  );
}

export default App;