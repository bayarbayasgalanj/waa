import { ADD_TODO, REMOVE_TODO, UPDATE_CALCULATOR_VALUE } from './actions';

const initialState = {
    todos: [],
    calculatorValue: 0,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case ADD_TODO:
            return {
                ...state,
                todos: [...state.todos, action.payload],
            };
        case REMOVE_TODO:
            return {
                ...state,
                todos: state.todos.filter((_, index) => index !== action.payload),
            };
        case UPDATE_CALCULATOR_VALUE:
            return {
                ...state,
                calculatorValue: action.payload,
            };
        default:
            return state;
    }
};

export default reducer;
