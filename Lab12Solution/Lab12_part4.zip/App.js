import React from 'react';
import { connect } from 'react-redux';
import TodoList from './TodoList';
import AddTodo from './AddTodo';
import Calculator from './Calculator';
import CombinedComponent from './CombinedComponent';

const App = () => {
    return (
        <div className="app">
            <h1>Todo List &amp; Calculator</h1>
            <TodoList />
            <AddTodo />
            <Calculator />
            <CombinedComponent />
        </div>
    );
};

export default App;
