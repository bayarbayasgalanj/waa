import React from 'react';
import { connect } from 'react-redux';
import TodoList from './TodoList';
import Calculator from './Calculator';

const CombinedComponent = ({ calculatorValue }) => {
    return (
        <div>
            <h2>Combined Component</h2>
            <TodoList />
            <Calculator />
            <div>Calculator Value: {calculatorValue}</div>
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        calculatorValue: state.calculatorValue,
    };
};

export default connect(mapStateToProps)(CombinedComponent);
